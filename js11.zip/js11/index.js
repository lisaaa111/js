/**
 * Главный модуль приложения
 * @module index
 */

import { 
    createTransaction, 
    addTransaction, 
    deleteTransaction, 
    getAllTransactions, 
    calculateTotal,
    initTestData
} from './transactions.js';

import {
    renderTransactions,
    addRowToTable,
    removeRowFromTable,
    updateTotalDisplay,
    displayTransactionDetails,
    showFormErrors,
    clearForm
} from './ui.js';

import { validateTransaction } from './utils.js';

// Инициализация тестовых данных
initTestData();

/**
 * Обновляет весь интерфейс (таблицу и итоговую сумму)
 */
function updateUI() {
    const transactions = getAllTransactions();
    renderTransactions(transactions);
    const total = calculateTotal();
    updateTotalDisplay(total);
}

/**
 * Обработчик добавления транзакции
 * @param {Event} event - Событие отправки формы
 */
function handleAddTransaction(event) {
    event.preventDefault();
    
    // Получаем данные из формы
    const amountInput = document.getElementById('amount');
    const categorySelect = document.getElementById('category');
    const descriptionInput = document.getElementById('description');
    
    const formData = {
        amount: amountInput.value,
        category: categorySelect.value,
        description: descriptionInput.value
    };
    
    // Валидация перед созданием
    const tempTransaction = {
        amount: parseFloat(formData.amount),
        category: formData.category,
        description: formData.description
    };
    
    const validation = validateTransaction(tempTransaction);
    
    if (!validation.isValid) {
        showFormErrors(validation.errors);
        return;
    }
    
    // Создаем транзакцию
    const newTransaction = createTransaction(formData);
    
    if (newTransaction) {
        // Добавляем в массив
        addTransaction(newTransaction);
        
        // Добавляем строку в таблицу
        addRowToTable(newTransaction);
        
        // Обновляем итоговую сумму
        const total = calculateTotal();
        updateTotalDisplay(total);
        
        // Очищаем форму
        clearForm();
    } else {
        showFormErrors(['Ошибка при создании транзакции']);
    }
}

/**
 * Обработчик удаления транзакции (через делегирование событий)
 * @param {Event} event - Событие клика
 */
function handleDeleteTransaction(event) {
    const deleteButton = event.target.closest('.btn-delete');
    if (!deleteButton) return;
    
    event.stopPropagation(); // Предотвращаем всплытие к обработчику строки
    
    const transactionId = deleteButton.dataset.id;
    
    if (transactionId) {
        // Удаляем из массива
        const deleted = deleteTransaction(transactionId);
        
        if (deleted) {
            // Удаляем строку из таблицы
            removeRowFromTable(transactionId);
            
            // Обновляем итоговую сумму
            const total = calculateTotal();
            updateTotalDisplay(total);
            
            // Если удаленная транзакция была показана в деталях, очищаем блок
            const detailsDiv = document.getElementById('transactionDetails');
            if (detailsDiv && detailsDiv.innerHTML.includes(transactionId)) {
                document.getElementById('transactionDetails').innerHTML = 
                    '<p class="placeholder">Нажмите на любую строку транзакции, чтобы увидеть полное описание</p>';
            }
        }
    }
}

/**
 * Обработчик клика по строке таблицы (показ подробного описания)
 * @param {Event} event - Событие клика
 */
function handleRowClick(event) {
    // Игнорируем клики по кнопке удаления
    if (event.target.classList.contains('btn-delete')) return;
    
    // Находим строку
    const row = event.target.closest('tr');
    if (row && row.dataset.id) {
        displayTransactionDetails(row.dataset.id);
    }
}

/**
 * Настройка обработчиков событий
 */
function setupEventListeners() {
    // Форма добавления
    const form = document.getElementById('transactionForm');
    if (form) {
        form.addEventListener('submit', handleAddTransaction);
    }
    
    // Делегирование событий для таблицы
    const table = document.getElementById('transactionsTable');
    if (table) {
        // Для удаления
        table.addEventListener('click', handleDeleteTransaction);
        // Для показа деталей
        table.addEventListener('click', handleRowClick);
    }
}

/**
 * Инициализация приложения
 */
function init() {
    // Отображаем существующие транзакции
    updateUI();
    
    // Настраиваем обработчики событий
    setupEventListeners();
    
    console.log('Приложение финансового учета инициализировано');
}

// Запускаем приложение после полной загрузки DOM
document.addEventListener('DOMContentLoaded', init);