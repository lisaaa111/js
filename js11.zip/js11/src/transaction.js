/**
 * Модуль управления транзакциями
 * @module transactions
 */

import { generateId, validateTransaction } from './utils.js';

// Массив транзакций (хранилище данных)
let transactions = [];

/**
 * Создает новую транзакцию
 * @param {Object} transactionData - Данные для создания транзакции
 * @param {number} transactionData.amount - Сумма транзакции
 * @param {string} transactionData.category - Категория
 * @param {string} transactionData.description - Описание
 * @returns {Object|null} Созданный объект транзакции или null при ошибке
 */
export function createTransaction(transactionData) {
    const newTransaction = {
        id: generateId(),
        date: new Date(),
        amount: parseFloat(transactionData.amount),
        category: transactionData.category.trim(),
        description: transactionData.description.trim()
    };
    
    // Валидация
    const validation = validateTransaction(newTransaction);
    if (!validation.isValid) {
        console.error('Ошибки валидации:', validation.errors);
        return null;
    }
    
    return newTransaction;
}

/**
 * Добавляет транзакцию в массив
 * @param {Object} transaction - Объект транзакции
 * @returns {boolean} Успешность добавления
 */
export function addTransaction(transaction) {
    if (!transaction || !transaction.id) return false;
    transactions.push(transaction);
    return true;
}

/**
 * Удаляет транзакцию из массива по ID
 * @param {string} id - Идентификатор транзакции
 * @returns {boolean} Успешность удаления
 */
export function deleteTransaction(id) {
    const initialLength = transactions.length;
    transactions = transactions.filter(transaction => transaction.id !== id);
    return transactions.length !== initialLength;
}

/**
 * Возвращает копию массива транзакций
 * @returns {Array} Массив транзакций
 */
export function getAllTransactions() {
    return [...transactions];
}

/**
 * Вычисляет общую сумму всех транзакций
 * @returns {number} Итоговая сумма
 */
export function calculateTotal() {
    return transactions.reduce((total, transaction) => {
        return total + transaction.amount;
    }, 0);
}

/**
 * Находит транзакцию по ID
 * @param {string} id - Идентификатор транзакции
 * @returns {Object|undefined} Найденная транзакция или undefined
 */
export function getTransactionById(id) {
    return transactions.find(transaction => transaction.id === id);
}

/**
 * Инициализирует тестовые данные (для демонстрации)
 */
export function initTestData() {
    if (transactions.length === 0) {
        const testTransactions = [
            {
                id: generateId(),
                date: new Date(2024, 0, 15, 10, 30),
                amount: 50000,
                category: 'Зарплата',
                description: 'Зарплата за январь 2024 года'
            },
            {
                id: generateId(),
                date: new Date(2024, 0, 16, 15, 20),
                amount: -3500,
                category: 'Продукты',
                description: 'Покупка продуктов в супермаркете Пятерочка'
            },
            {
                id: generateId(),
                date: new Date(2024, 0, 17, 9, 0),
                amount: -1200,
                category: 'Транспорт',
                description: 'Пополнение транспортной карты'
            }
        ];
        transactions.push(...testTransactions);
    }
}