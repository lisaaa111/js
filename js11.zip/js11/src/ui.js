/**
 * Модуль для работы с DOM-интерфейсом
 * @module ui
 */

import { formatDateTime, truncateToWords } from './utils.js';
import { deleteTransaction, getTransactionById } from './transactions.js';

// DOM элементы
const tableBody = document.getElementById('tableBody');
const totalAmountSpan = document.getElementById('totalAmount');
const transactionDetailsDiv = document.getElementById('transactionDetails');

/**
 * Отображает все транзакции в таблице
 * @param {Array} transactions - Массив транзакций
 */
export function renderTransactions(transactions) {
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    transactions.forEach(transaction => {
        const row = createTableRow(transaction);
        tableBody.appendChild(row);
    });
}

/**
 * Создает строку таблицы для транзакции
 * @param {Object} transaction - Объект транзакции
 * @returns {HTMLTableRowElement} Созданная строка таблицы
 */
export function createTableRow(transaction) {
    const row = document.createElement('tr');
    row.dataset.id = transaction.id;
    
    // Определяем класс для цвета строки
    if (transaction.amount >= 0) {
        row.classList.add('positive');
    } else {
        row.classList.add('negative');
    }
    
    // Создаем ячейки
    const dateCell = document.createElement('td');
    dateCell.textContent = formatDateTime(transaction.date);
    
    const categoryCell = document.createElement('td');
    categoryCell.textContent = transaction.category;
    
    const amountCell = document.createElement('td');
    const sign = transaction.amount >= 0 ? '+' : '';
    amountCell.textContent = `${sign}${transaction.amount.toFixed(2)}`;
    
    const descCell = document.createElement('td');
    descCell.textContent = truncateToWords(transaction.description, 4);
    
    const actionCell = document.createElement('td');
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Удалить';
    deleteBtn.className = 'btn-delete';
    deleteBtn.dataset.id = transaction.id;
    actionCell.appendChild(deleteBtn);
    
    row.appendChild(dateCell);
    row.appendChild(categoryCell);
    row.appendChild(amountCell);
    row.appendChild(descCell);
    row.appendChild(actionCell);
    
    return row;
}

/**
 * Добавляет одну строку в таблицу
 * @param {Object} transaction - Объект транзакции
 */
export function addRowToTable(transaction) {
    if (!tableBody) return;
    const row = createTableRow(transaction);
    tableBody.appendChild(row);
}

/**
 * Удаляет строку из таблицы по ID транзакции
 * @param {string} transactionId - ID транзакции
 */
export function removeRowFromTable(transactionId) {
    if (!tableBody) return;
    const row = document.querySelector(`tr[data-id="${transactionId}"]`);
    if (row) {
        row.remove();
    }
}

/**
 * Обновляет отображение итоговой суммы
 * @param {number} total - Итоговая сумма
 */
export function updateTotalDisplay(total) {
    if (totalAmountSpan) {
        totalAmountSpan.textContent = total.toFixed(2);
        
        // Меняем цвет отображения итога
        if (total >= 0) {
            totalAmountSpan.style.color = '#90EE90';
        } else {
            totalAmountSpan.style.color = '#FFB6C1';
        }
    }
}

/**
 * Отображает подробное описание транзакции
 * @param {string} transactionId - ID транзакции
 */
export function displayTransactionDetails(transactionId) {
    if (!transactionDetailsDiv) return;
    
    const transaction = getTransactionById(transactionId);
    
    if (!transaction) {
        transactionDetailsDiv.innerHTML = '<p class="placeholder">Транзакция не найдена</p>';
        return;
    }
    
    const amountClass = transaction.amount >= 0 ? 'доход' : 'расход';
    const amountColor = transaction.amount >= 0 ? '#28a745' : '#dc3545';
    
    transactionDetailsDiv.innerHTML = `
        <div style="padding: 10px;">
            <p><strong>ID:</strong> ${transaction.id}</p>
            <p><strong>Дата:</strong> ${formatDateTime(transaction.date)}</p>
            <p><strong>Категория:</strong> ${transaction.category}</p>
            <p><strong>Сумма:</strong> <span style="color: ${amountColor}; font-weight: bold;">${transaction.amount >= 0 ? '+' : ''}${transaction.amount.toFixed(2)} ₽</span> <span style="color: #666;">(${amountClass})</span></p>
            <p><strong>Полное описание:</strong> ${escapeHtml(transaction.description)}</p>
        </div>
    `;
}

/**
 * Вспомогательная функция для экранирования HTML
 * @param {string} str - Строка для экранирования
 * @returns {string} Экранированная строка
 */
function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/**
 * Отображает ошибки валидации на форме
 * @param {Array} errors - Массив ошибок
 */
export function showFormErrors(errors) {
    // Удаляем предыдущие сообщения об ошибках
    const existingErrors = document.querySelectorAll('.error-message');
    existingErrors.forEach(err => err.remove());
    
    // Убираем классы ошибок с полей
    const inputs = document.querySelectorAll('#amount, #category, #description');
    inputs.forEach(input => input.classList.remove('error-input'));
    
    // Показываем новые ошибки
    errors.forEach(error => {
        let fieldId = '';
        if (error.includes('Сумма')) fieldId = 'amount';
        else if (error.includes('Категория')) fieldId = 'category';
        else if (error.includes('Описание')) fieldId = 'description';
        
        if (fieldId) {
            const field = document.getElementById(fieldId);
            if (field) {
                field.classList.add('error-input');
                const errorSpan = document.createElement('span');
                errorSpan.className = 'error-message';
                errorSpan.textContent = error;
                field.parentNode.appendChild(errorSpan);
            }
        } else {
            // Общая ошибка
            const form = document.getElementById('transactionForm');
            const errorSpan = document.createElement('span');
            errorSpan.className = 'error-message';
            errorSpan.textContent = error;
            form.appendChild(errorSpan);
            setTimeout(() => errorSpan.remove(), 3000);
        }
    });
}

/**
 * Очищает форму добавления транзакции
 */
export function clearForm() {
    const form = document.getElementById('transactionForm');
    if (form) {
        form.reset();
    }
    
    // Удаляем подсветку ошибок
    const errorInputs = document.querySelectorAll('.error-input');
    errorInputs.forEach(input => input.classList.remove('error-input'));
    
    const errorMessages = document.querySelectorAll('.error-message');
    errorMessages.forEach(msg => msg.remove());
}