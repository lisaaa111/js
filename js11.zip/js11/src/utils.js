/**
 * Модуль вспомогательных функций
 * @module utils
 */

/**
 * Генерирует уникальный идентификатор на основе временной метки и случайного числа
 * @returns {string} Уникальный идентификатор
 */
export function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

/**
 * Форматирует дату в локальный формат с временем
 * @param {Date} date - Объект даты для форматирования
 * @returns {string} Отформатированная строка даты и времени
 */
export function formatDateTime(date) {
    const options = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    return new Date(date).toLocaleString('ru-RU', options);
}

/**
 * Обрезает строку до указанного количества слов
 * @param {string} text - Исходный текст
 * @param {number} wordCount - Количество слов для отображения
 * @returns {string} Обрезанная строка
 */
export function truncateToWords(text, wordCount = 4) {
    if (!text) return '';
    const words = text.trim().split(/\s+/);
    if (words.length <= wordCount) return text;
    return words.slice(0, wordCount).join(' ') + '...';
}

/**
 * Валидирует данные транзакции
 * @param {Object} transaction - Объект транзакции для валидации
 * @param {number} transaction.amount - Сумма транзакции
 * @param {string} transaction.category - Категория
 * @param {string} transaction.description - Описание
 * @returns {Object} Результат валидации { isValid: boolean, errors: string[] }
 */
export function validateTransaction(transaction) {
    const errors = [];
    
    if (transaction.amount === undefined || isNaN(transaction.amount)) {
        errors.push('Сумма должна быть числом');
    }
    
    if (!transaction.category || transaction.category.trim() === '') {
        errors.push('Категория не может быть пустой');
    }
    
    if (!transaction.description || transaction.description.trim().length < 2) {
        errors.push('Описание должно содержать минимум 2 символа');
    }
    
    if (transaction.description && transaction.description.length > 200) {
        errors.push('Описание не должно превышать 200 символов');
    }
    
    return {
        isValid: errors.length === 0,
        errors
    };
}