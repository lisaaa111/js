const charactersData = [
    { id: 1, name: "Draculaura", species: "Vampire", faction: "Vampires", likes: 245, quote: "Bite me if you can!", year: 2010, imageUrl: "images/image1.jpg", color: "#FF69B4" },
    { id: 2, name: "Clawdeen Wolf", species: "Werewolf", faction: "Werewolves", likes: 312, quote: "Fierce and fang-tastic!", year: 2010, imageUrl: "images/image2.jpg", color: "#8B4513" },
    { id: 3, name: "Cleo de Nile", species: "Mummy", faction: "Ancient Creatures", likes: 278, quote: "Royalty speaks, you listen.", year: 2010, imageUrl: "images/image3.jpg", color: "#DAA520" },
    { id: 4, name: "Spectra Vondergeist", species: "Ghost", faction: "Ghosts", likes: 198, quote: "I see right through you!", year: 2011, imageUrl: "images/image4.jpg", color: "#9370DB" },
    { id: 5, name: "Frankie Stein", species: "Frankenstein", faction: "Monsters", likes: 301, quote: "Electrifying!", year: 2010, imageUrl: "images/image5.jpg", color: "#7CFC00" },
    { id: 6, name: "Lagoona Blue", species: "Sea Monster", faction: "Water Creatures", likes: 187, quote: "Make a splash!", year: 2010, imageUrl: "images/image6.jpg", color: "#00CED1" },
    { id: 7, name: "Ghoulia Yelps", species: "Zombie", faction: "Zombies", likes: 156, quote: "Brains... I mean, hi!", year: 2010, imageUrl: "images/image7.jpg", color: "#808080" },
    { id: 8, name: "Abbey Bominable", species: "Yeti", faction: "Ice Creatures", likes: 167, quote: "Ice to meet you!", year: 2011, imageUrl: "images/image8.jpg", color: "#B0E0E6" }
];