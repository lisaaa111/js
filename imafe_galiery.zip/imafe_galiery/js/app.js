// js/app.js
import { charactersData } from './data.js';
import { Gallery } from './gallery.js';
import { FilterManager } from './filters.js';

document.addEventListener('DOMContentLoaded', () => {
  const gallery = new Gallery('galleryContainer');
  const filterManager = new FilterManager(charactersData, (filtered) => {
    gallery.render(filtered);
  });

  // Get DOM elements
  const speciesFilter = document.getElementById('speciesFilter');
  const factionFilter = document.getElementById('factionFilter');
  const sortBy = document.getElementById('sortBy');
  const orderSelect = document.getElementById('order');
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  const resetBtn = document.getElementById('resetBtn');

  // Event listeners
  speciesFilter.addEventListener('change', (e) => {
    filterManager.updateFilter('species', e.target.value);
  });

  factionFilter.addEventListener('change', (e) => {
    filterManager.updateFilter('faction', e.target.value);
  });

  sortBy.addEventListener('change', (e) => {
    filterManager.updateFilter('sortBy', e.target.value);
  });

  orderSelect.addEventListener('change', (e) => {
    filterManager.updateFilter('order', e.target.value);
  });

  searchBtn.addEventListener('click', () => {
    filterManager.updateFilter('search', searchInput.value);
  });

  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      filterManager.updateFilter('search', searchInput.value);
    }
  });

  // Validation for search
  searchInput.addEventListener('input', () => {
    if (searchInput.value.length > 25) {
      alert('Search query must be less than 25 characters!');
      searchInput.value = searchInput.value.slice(0, 25);
    }
  });

  // Reset all filters
  resetBtn.addEventListener('click', () => {
    speciesFilter.value = 'all';
    factionFilter.value = 'all';
    sortBy.value = 'likes';
    orderSelect.value = 'desc';
    searchInput.value = '';
    
    filterManager.updateFilter('species', 'all');
    filterManager.updateFilter('faction', 'all');
    filterManager.updateFilter('sortBy', 'likes');
    filterManager.updateFilter('order', 'desc');
    filterManager.updateFilter('search', '');
  });

  // Initial render
  filterManager.applyFilters();
});