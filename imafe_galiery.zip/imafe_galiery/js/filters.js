// js/filters.js
export class FilterManager {
  constructor(characters, onFilterChange) {
    this.characters = [...characters];
    this.onFilterChange = onFilterChange;
    this.filters = {
      species: 'all',
      faction: 'all',
      sortBy: 'likes',
      order: 'desc',
      search: ''
    };
  }

  updateFilter(key, value) {
    this.filters[key] = value;
    this.applyFilters();
  }

  applyFilters() {
    let result = [...this.characters];

    // Filter by species
    if (this.filters.species !== 'all') {
      result = result.filter(c => c.species === this.filters.species);
    }

    // Filter by faction
    if (this.filters.faction !== 'all') {
      result = result.filter(c => c.faction === this.filters.faction);
    }

    // Search by name
    if (this.filters.search.trim()) {
      const query = this.filters.search.toLowerCase();
      result = result.filter(c => c.name.toLowerCase().includes(query));
    }

    // Sort
    result.sort((a, b) => {
      let valA, valB;
      if (this.filters.sortBy === 'likes') {
        valA = a.likes;
        valB = b.likes;
      } else if (this.filters.sortBy === 'year') {
        valA = a.year;
        valB = b.year;
      } else {
        valA = a.name;
        valB = b.name;
      }
      
      if (this.filters.order === 'asc') {
        return valA > valB ? 1 : -1;
      } else {
        return valA < valB ? 1 : -1;
      }
    });

    this.onFilterChange(result);
  }
}