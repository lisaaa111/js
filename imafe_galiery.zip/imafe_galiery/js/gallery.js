// js/gallery.js
export class Gallery {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.currentCharacters = [];
  }

  render(characters) {
    this.currentCharacters = characters;
    
    if (!this.container) return;
    
    if (characters.length === 0) {
      this.container.innerHTML = `
        <div class="no-results">
           No monsters found! Try different filters. 
        </div>
      `;
      return;
    }

    this.container.innerHTML = characters.map(character => `
      <div class="gallery-card" data-id="${character.id}" style="border-top: 4px solid ${character.color}">
        <div class="card-image">
          <img src="${character.imageUrl}" alt="${character.name}" loading="lazy">
          <span class="likes-badge"> ${character.likes}</span>
        </div>
        <div class="card-content">
          <h3>${character.name}</h3>
          <p class="species">${character.species} • ${character.year}</p>
          <p class="quote">"${character.quote}"</p>
          <span class="faction-tag">${character.faction}</span>
        </div>
      </div>
    `).join('');

    // Add click handlers for modal
    document.querySelectorAll('.gallery-card').forEach(card => {
      card.addEventListener('click', (e) => {
        const id = parseInt(card.dataset.id);
        const character = this.currentCharacters.find(c => c.id === id);
        if (character) this.openModal(character);
      });
    });
  }

  openModal(character) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal-container" style="border-color: ${character.color}">
        <button class="modal-close">✖</button>
        <div class="modal-grid">
          <div class="modal-image">
            <img src="${character.imageUrl}" alt="${character.name}">
          </div>
          <div class="modal-info">
            <h2>${character.name}</h2>
            <p class="modal-species"> ${character.species} |  ${character.year}</p>
            <p class="modal-faction"> Faction: ${character.faction}</p>
            <p class="modal-quote"> "${character.quote}"</p>
            <div class="modal-likes"> ${character.likes} nightmares (likes)</div>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
    
    const closeBtn = modal.querySelector('.modal-close');
    closeBtn.addEventListener('click', () => modal.remove());
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.remove();
    });
  }
}